function mouseOver(){
    document.imagem.src="image/cat02.jpg";
}
function mouseOut(){
    document.imagem.src="image/cat01.jpg"
}